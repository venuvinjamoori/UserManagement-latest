package com.mcb.model;

/**
 * Bean for displaying services mapped to users
 * 
 * @author Administrator
 *
 */
public class McbMap {

	private Integer userId;

	private Integer serviceId;

	private String hasAccess;
	
	public String getHasAccess() {
		return hasAccess;
	}

	public void setHasAccess(String hasAccess) {
		this.hasAccess = hasAccess;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

}
