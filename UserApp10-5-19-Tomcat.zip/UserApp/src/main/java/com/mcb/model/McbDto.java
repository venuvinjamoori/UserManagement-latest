package com.mcb.model;

public interface McbDto {

	public String getUserName();

	public String getMcbService();

	public String getHasAccess();
}
