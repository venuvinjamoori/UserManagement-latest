package com.mcb.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the MCB_USER_INFO database table.
 * 
 */
@Entity
@Table(name = "MCB_USER_INFO")
@NamedQuery(name = "McbUserInfo.findAll", query = "SELECT m FROM McbUserInfo m")
public class McbUserInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "usrSeqGen", sequenceName = "usrSeq", initialValue = 1, allocationSize = 1)
	@GeneratedValue(generator = "usrSeqGen")
	@Column(name = "USER_ID")
	private Integer userId;

	@Column(name = "USER_NAME", unique = true)
	private String userName;

	@Column(name = "USER_ROLE")
	private String userRole;

	@Column(name = "ROLE_DESCRIPTION")
	private String roleDescription;

	@Column(name = "USER_ACTIVE")
	private String userActive;

	@Column(name = "PASSWORD_HASH")
	private String passwordHash;

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "UPDATED_DATE")
	private Date updatedDate;

	public McbUserInfo() {
	}

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getPasswordHash() {
		return this.passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	public String getRoleDescription() {
		return this.roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public Date getUpdatedDate() {
		return this.updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUserActive() {
		return this.userActive;
	}

	public void setUserActive(String userActive) {
		this.userActive = userActive;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserRole() {
		return this.userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

}