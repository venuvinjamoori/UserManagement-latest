package com.mcb.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the MCB_SERVICES_INFO database table.
 * 
 */
@Entity
@Table(name="MCB_SERVICES_INFO")
@NamedQuery(name="McbServicesInfo.findAll", query="SELECT m FROM McbServicesInfo m")
public class McbServicesInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "servSeqGen", sequenceName = "servSeq", initialValue = 1)
	@GeneratedValue(generator = "servSeqGen")
	@Column(name="SERVICE_ID")
	private Integer serviceId;

	@Column(name="MCB_SERVICE", unique=true)
	private String mcbService;

	@Column(name="MCB_SERVICE_DESC")
	private String mcbServiceDesc;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Temporal(TemporalType.DATE)
	@Column(name="UPDATED_DATE")
	private Date updatedDate;

	public McbServicesInfo() {
	}

	public Integer getServiceId() {
		return this.serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getMcbService() {
		return this.mcbService;
	}

	public void setMcbService(String mcbService) {
		this.mcbService = mcbService;
	}

	public String getMcbServiceDesc() {
		return this.mcbServiceDesc;
	}

	public void setMcbServiceDesc(String mcbServiceDesc) {
		this.mcbServiceDesc = mcbServiceDesc;
	}

	public Date getUpdatedDate() {
		return this.updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

}