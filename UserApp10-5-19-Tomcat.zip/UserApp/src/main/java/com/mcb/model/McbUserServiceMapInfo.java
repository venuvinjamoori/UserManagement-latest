package com.mcb.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the MCB_USER_SERVICE_MAP_INFO database table.
 * 
 */
@Entity
@Table(name="MCB_USER_SERVICE_MAP_INFO")
@NamedQuery(name="McbUserServiceMapInfo.findAll", query="SELECT m FROM McbUserServiceMapInfo m")
public class McbUserServiceMapInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private McbUserServiceMapInfoPK id;

	@Column(name="HAS_ACCESS")
	private String hasAccess;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Temporal(TemporalType.DATE)
	@Column(name="UPDATED_DATE")
	private Date updatedDate;

	public McbUserServiceMapInfo() {
	}

	public McbUserServiceMapInfoPK getId() {
		return this.id;
	}

	public void setId(McbUserServiceMapInfoPK id) {
		this.id = id;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getHasAccess() {
		return this.hasAccess;
	}

	public void setHasAccess(String hasAccess) {
		this.hasAccess = hasAccess;
	}

	public Date getUpdatedDate() {
		return this.updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String toString() {
		return "McbUserServiceMapInfo [id=" + id + ", createdDate=" + createdDate + ", hasAccess=" + hasAccess
				+ ", updatedDate=" + updatedDate + "]";
	}

	
}