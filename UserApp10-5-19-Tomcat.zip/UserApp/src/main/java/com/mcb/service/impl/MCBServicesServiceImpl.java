package com.mcb.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mcb.model.McbServicesInfo;
import com.mcb.rpository.MCBServiceRepository;
import com.mcb.services.MCBServicesService;


@Service
public class MCBServicesServiceImpl implements MCBServicesService {
	@Autowired
	private MCBServiceRepository serviceRepository;

	@Override
	public Integer saveMCBService(McbServicesInfo service) {
		service=serviceRepository.save(service);
		Integer serviceId=service.getServiceId();
		return serviceId;
	}

	@Override
	public void deleteMCBService(Integer serviceId) {
		serviceRepository.deleteById(serviceId);
		
	}

	@Override
	public McbServicesInfo getserviceById(Integer serviceId) {
		Optional<McbServicesInfo> p=serviceRepository.findById(serviceId);
		if(p.isPresent()) {
			return p.get();
		}else {
			return new McbServicesInfo();
		}
	}

	@Override
	public List<McbServicesInfo> getAllMCBServices() {
		List<McbServicesInfo> services=serviceRepository.findAll();
		return services;
	}
	
	
	@Override
	public Date findCreatedDate(Integer serviceId) {
		return serviceRepository.findCreatedDate(serviceId);
	}
	

}
