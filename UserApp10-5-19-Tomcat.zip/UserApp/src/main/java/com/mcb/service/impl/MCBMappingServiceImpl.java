package com.mcb.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mcb.model.McbDto;
import com.mcb.model.McbUserServiceMapInfo;
import com.mcb.model.McbUserServiceMapInfoPK;
import com.mcb.rpository.MCBMappingRepository;
import com.mcb.services.MCBMappingService;

@Service
public class MCBMappingServiceImpl implements MCBMappingService{

	
	@Autowired
	private MCBMappingRepository mappingRepository;


	@Override
	public McbUserServiceMapInfoPK saveUserService(McbUserServiceMapInfo mapping) {
		mapping=mappingRepository.save(mapping);
		McbUserServiceMapInfoPK Id=mapping.getId();
		return Id;
	}

	@Override
	public List<McbUserServiceMapInfo> getAllMapping() {
		List<McbUserServiceMapInfo> mapping =mappingRepository.findAll();
		return mapping;
	}
	
	@Override	
	public 	List<McbDto> findServicesByUserId(Integer user_id) {
		List<McbDto> mcbDAO =mappingRepository.findServicesByUserId(user_id);
		return mcbDAO;
	}

	@Override	
	public 	List<McbDto> findUsersByServiceId(Integer user_id) {
		List<McbDto> mcbDAO =mappingRepository.findUsersByServiceId(user_id);
		return mcbDAO;
	}
	
	public List<McbDto> findUsersServiceMap(String has_access){
		List<McbDto> mcbDAO =mappingRepository.findUsersServiceMap(has_access);
		return mcbDAO;
	}
	
	@Override
	public Date findCreatedDate(Integer userId,Integer serviceId) {
		return mappingRepository.findCreatedDate(userId,serviceId);
	}
	


}
