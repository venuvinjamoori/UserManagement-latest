package com.mcb.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mcb.model.McbUserInfo;
import com.mcb.rpository.MCBUserRepository;
import com.mcb.services.MCBUserService;


@Service
public class MCBUserServiceImpl implements MCBUserService {
	@Autowired
	private MCBUserRepository userRepository;

	@Override
	public Integer saveUser(McbUserInfo user) {
		user=userRepository.save(user);
		Integer userId=user.getUserId();
		return userId;
	}

	@Override
	public void deleteUser(Integer userId) {
//		userRepository.deleteById(userId);
		McbUserInfo mcbUserInfo = getuserById(userId);
		mcbUserInfo.setUserActive("N");
		userRepository.save(mcbUserInfo);
	}

	@Override
	public McbUserInfo getuserById(Integer userId) {
		Optional<McbUserInfo> p=userRepository.findById(userId);
		if(p.isPresent()) {
			return p.get();
		}else {
			return new McbUserInfo();
		}
	}

	@Override
	public List<McbUserInfo> getAllUsers() {
		List<McbUserInfo> users=userRepository.findAll();
		return users;
	}
	
	public String findPassByUserName(String userName) {
		return userRepository.findPassByUserName(userName);
	}

	@Override
	public Date findCreatedDate(Integer userId) {
		// TODO Auto-generated method stub
		return userRepository.findCreatedDate(userId);
	}

}
