package com.mcb.rpository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mcb.model.McbDto;
import com.mcb.model.McbUserServiceMapInfo;

/**
 * Repository to map services to user.
 * 
 * @author Administrator
 *
 */

@Repository
public interface MCBMappingRepository extends JpaRepository<McbUserServiceMapInfo, Integer>{

	//Get all services associated with given user from Mapping table
	@Query(value = " select u.USER_NAME AS userName,s.MCB_SERVICE AS mcbService,m.HAS_ACCESS AS hasAccess"
			+ " from MCB_USER_INFO u "
			+ " join MCB_USER_SERVICE_MAP_INFO m on u.USER_ID=m.USER_ID "
			+ " join MCB_SERVICES_INFO s on s.SERVICE_ID=m.SERVICE_ID "
			+ " where m.user_id = :user_id ", nativeQuery = true)
	List<McbDto> findServicesByUserId(@Param("user_id") Integer user_id);

	//Get all user associated with given services from Mapping table	
	@Query(value = " select u.USER_NAME AS userName,s.MCB_SERVICE AS mcbService,m.HAS_ACCESS AS hasAccess"
			+ " from MCB_USER_INFO u "
			+ " join MCB_USER_SERVICE_MAP_INFO m on u.USER_ID=m.USER_ID "
			+ " join MCB_SERVICES_INFO s on s.SERVICE_ID=m.SERVICE_ID "
			+ " where m.service_id = :service_id ", nativeQuery = true)
	List<McbDto> findUsersByServiceId(@Param("service_id") Integer service_id);

	//Get all services associated with all user from Mapping table when user has the access to it is written as Yes
	@Query(value = " select u.USER_NAME AS userName,s.MCB_SERVICE AS mcbService,m.HAS_ACCESS AS hasAccess"
			+ " from MCB_USER_INFO u "
			+ " join MCB_USER_SERVICE_MAP_INFO m on u.USER_ID=m.USER_ID "
			+ " join MCB_SERVICES_INFO s on s.SERVICE_ID=m.SERVICE_ID "
			+ " where m.has_access = :has_access ", nativeQuery = true)
	List<McbDto> findUsersServiceMap(@Param("has_access") String has_access);

	@Query(value = "SELECT CREATED_DATE FROM MCB_USER_SERVICE_MAP_INFO where  USER_ID = :userId and SERVICE_ID = :serviceId", nativeQuery = true)
	Date findCreatedDate(Integer userId,Integer serviceId);
}