package com.mcb.rpository;


import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mcb.model.McbUserInfo;

/**
 * Repository for user.
 * 
 * @author Administrator
 *
 */

@Repository
public interface MCBUserRepository extends JpaRepository<McbUserInfo, Integer> { 
	
	@Query(value = "select PASSWORD_HASH from MCB_USER_INFO where USER_NAME = :userName ", nativeQuery = true)
	String findPassByUserName(String userName);

	@Query(value = "SELECT CREATED_DATE FROM MCB_USER_INFO where USER_ID = :userId", nativeQuery = true)
	Date findCreatedDate(Integer userId);
}
