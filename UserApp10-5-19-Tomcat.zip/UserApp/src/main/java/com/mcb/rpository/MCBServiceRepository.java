package com.mcb.rpository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mcb.model.McbServicesInfo;

/**
 * Repository for services .
 * 
 * @author Administrator
 *
 */

@Repository
public interface MCBServiceRepository  extends JpaRepository<McbServicesInfo, Integer>{
	
	@Query(value = "SELECT CREATED_DATE FROM MCB_SERVICES_INFO where SERVICE_ID = :serviceId", nativeQuery = true)
	Date findCreatedDate(Integer serviceId);

}
