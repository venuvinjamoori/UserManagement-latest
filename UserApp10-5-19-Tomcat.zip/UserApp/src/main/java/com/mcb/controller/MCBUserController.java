package com.mcb.controller;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mcb.model.McbUserInfo;
import com.mcb.services.HashingPW;
import com.mcb.services.MCBUserService;

@Controller
@RequestMapping("/user")
public class MCBUserController {
	@Autowired
	private MCBUserService userService;

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String showPage(Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {
			// set form backing object-[Form<=>Object]
			model.addAttribute("user", new McbUserInfo());
			
			return "UserRegister";
		} else {
			return "login";
		}
	}

	// 2. save/update data
	@RequestMapping(value = "/save", method = POST)
	public String saveUser(@ModelAttribute McbUserInfo user, Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {

			// Take system date as Updated date and Created date
			if(user.getUserId()==null) //If new user id is generated set created date
			{
				user.setCreatedDate(new java.sql.Date(new Date().getTime()));
				System.out.println("NewUser");
			}
			else {
				user.setCreatedDate( userService.findCreatedDate(user.getUserId()) );
				System.out.println("ExistingUser");
				}
			user.setUpdatedDate(new java.sql.Date(new Date().getTime()));
			System.out.println("CD"+user.getCreatedDate());
			System.out.println("UD"+user.getUpdatedDate());
			// Password hashing
			user.setPasswordHash(HashingPW.encryptThisString(user.getPasswordHash()));

			try {
				// save operation
				Integer userId = userService.saveUser(user);
				// clean form
				model.addAttribute("user", new McbUserInfo());
				// return message to UI
				model.addAttribute("message", "User '" + userId + "' saved");
			} catch (Exception e) {

				model.addAttribute("user", user);
				model.addAttribute("message", "User " + user.getUserId() + " is already present .");
			}

			return "UserRegister";

		} else {
			return "login";
		}
	}

	// 3. display all values
	@RequestMapping("/all")
	public String showAllUsers(Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {
			List<McbUserInfo> users = userService.getAllUsers();
			model.addAttribute("list", users);
			return "UserData";
		} else {
			return "login";
		}
	}

	// 4. Delete User based on PathVariable-id
	@RequestMapping("/delete/{id}")
	public String deleteUser(@PathVariable Integer id, Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {
			// delete record
			userService.deleteUser(id);
			// get new data and goto UI
			List<McbUserInfo> users = userService.getAllUsers();
			model.addAttribute("message", "User '" + id + "' Deleted");
			model.addAttribute("list", users);
			return "UserData";
		} else {
			return "login";
		}
	}

	// 5. show Edit Page
	@RequestMapping("/edit/{id}")
	public String showEditPage(@PathVariable Integer id, Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {
			// load user from DB
			McbUserInfo user = userService.getuserById(id);

			// send object to UI => Form data
			model.addAttribute("user", user);
			return "UserRegister";
		} else {
			return "login";
		}
	}
}