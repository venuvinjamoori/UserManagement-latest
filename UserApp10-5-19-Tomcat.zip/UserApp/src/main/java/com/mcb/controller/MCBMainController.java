package com.mcb.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mcb.model.McbUserInfo;
import com.mcb.services.HashingPW;
import com.mcb.services.MCBUserService;

/**
 * login controller
 * 
 * @author Administrator
 *
 */
@Controller
@RequestMapping
public class MCBMainController {

	@Autowired
	private MCBUserService userService;

	// request mapping for Login page
	@RequestMapping("/login")
	public String Login(HttpSession session) {

		session.invalidate();
		return "Login";
	}

	// request mapping for Home page
	@RequestMapping("/home")
	public String UserAndService(@ModelAttribute McbUserInfo user, Model model, HttpSession session) {

		if ((session.getAttribute("UserName") != null) || (user.getUserName() != null)) {
			if ((user.getUserName() != null)) {
				String pass = userService.findPassByUserName(user.getUserName());

				if (pass != null && pass.equals(HashingPW.encryptThisString(user.getPasswordHash()))) {

					session.setAttribute("UserName", user.getUserName());
					return "index";
				} else {
					model.addAttribute("error", "Your User name or Password is invalid.");
					return "Login";
				}
			} else if (session.getAttribute("UserName") != null) {
				return "index";
			} else {
				model.addAttribute("error", "Your User name or Password is invalid.");
				return "Login";
			}
		} else {
			model.addAttribute("error", "Your User name or Password is invalid.");
			return "Login";
		}
	}
}