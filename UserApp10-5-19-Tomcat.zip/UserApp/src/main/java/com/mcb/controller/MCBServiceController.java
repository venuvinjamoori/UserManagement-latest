package com.mcb.controller;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mcb.model.McbServicesInfo;
import com.mcb.services.MCBServicesService;

/**
 * Service controller
 * 
 * @author Administrator
 *
 */

@Controller
@RequestMapping("/service")
public class MCBServiceController {
	@Autowired
	private MCBServicesService serviceService;

	// 1.Add new service
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String showPage(Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {
			// set form backing object-[Form<=>Object]
			model.addAttribute("service", new McbServicesInfo());
			return "ServiceRegister";
		} else {
			return "login";
		}
	}

	// 2. save/update data
	@RequestMapping(value = "/save", method = POST)
	public String saveService(@ModelAttribute McbServicesInfo service, Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {

			// Take system date as Updated date and Created date
			if (service.getServiceId() == null) // If new user id is generated set created date
			{
				service.setCreatedDate(new java.sql.Date(new Date().getTime()));
				System.out.println("NewUser");
			} else {
				service.setCreatedDate(serviceService.findCreatedDate(service.getServiceId()));
				System.out.println("ExistingUser");
			}
			service.setUpdatedDate(new java.sql.Date(new Date().getTime()));
			try {
				// save operation
				Integer serviceId = serviceService.saveMCBService(service);
				// clean form
				model.addAttribute("service", new McbServicesInfo());
				// return message to UI
				model.addAttribute("message", "Service '" + serviceId + "' saved");
			} catch (Exception e) {
				model.addAttribute("service", service);
				// showEditPage(service.getServiceId(),model,session);
				model.addAttribute("message", "Service not saved .As it's already present .");
			}
			return "ServiceRegister";
		} else {
			return "login";
		}
	}

	// 3. Display all services
	@RequestMapping("/all")
	public String showAllServices(Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {
			List<McbServicesInfo> services = serviceService.getAllMCBServices();
			model.addAttribute("list", services);
			return "ServiceData";
		} else {
			return "login";
		}
	}

	// 4. Delete Service based on Service id
	@RequestMapping("/delete/{id}")
	public String deleteService(@PathVariable Integer id, Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {

			try {
				// delete record
				serviceService.deleteMCBService(id);
				model.addAttribute("message", "Service '" + id + "' Deleted");
			} catch (Exception e) {
				model.addAttribute("message", "Service can not be deleted as integrity constraint violated - child record found");
			}

			List<McbServicesInfo> services = serviceService.getAllMCBServices();
			model.addAttribute("list", services);
			// get new data and goto UI
			return "ServiceData";
		} else {
			return "login";
		}
	}

	// 5.Edit service data
	@RequestMapping("/edit/{id}")
	public String showEditPage(@PathVariable Integer id, Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {
			// load service from DB
			McbServicesInfo p = serviceService.getserviceById(id);
			// send object to UI => Form data
			model.addAttribute("service", p);
			return "ServiceRegister";
		} else {
			return "login";
		}
	}
}