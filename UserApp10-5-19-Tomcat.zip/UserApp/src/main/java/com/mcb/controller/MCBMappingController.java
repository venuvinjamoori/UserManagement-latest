package com.mcb.controller;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.util.Date;
import java.util.List;
import java.util.ListIterator;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mcb.model.McbDto;
import com.mcb.model.McbMap;
import com.mcb.model.McbServicesInfo;
import com.mcb.model.McbUserInfo;
import com.mcb.model.McbUserServiceMapInfo;
import com.mcb.model.McbUserServiceMapInfoPK;
import com.mcb.services.MCBMappingService;
import com.mcb.services.MCBServicesService;
import com.mcb.services.MCBUserService;

/**
 * User and Service Mapping controller
 * 
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/mapping")
public class MCBMappingController {

	@Autowired
	private MCBServicesService serviceService;

	@Autowired
	private MCBUserService userService;

	@Autowired
	private MCBMappingService mappingService;

	// 1.Map users to service
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String serviceUserMappings(Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {
			List<McbServicesInfo> services = serviceService.getAllMCBServices();
			model.addAttribute("serviceList", services);

			List<McbUserInfo> users = userService.getAllUsers();
			model.addAttribute("userList", users);

			return "MappingRegister";
		} else {
			return "login";
		}
	}

	// 2.save after mapping
	@RequestMapping(value = "/save", method = POST)
	public String saveUserServiceMap(@ModelAttribute McbMap mcbMap, Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {

			McbUserServiceMapInfoPK mcbUserServiceMapInfoPK = new McbUserServiceMapInfoPK();
			mcbUserServiceMapInfoPK.setServiceId(mcbMap.getServiceId());
			mcbUserServiceMapInfoPK.setUserId(mcbMap.getUserId());

			McbUserServiceMapInfo mcbUserServiceMapInfo = new McbUserServiceMapInfo();

			mcbUserServiceMapInfo.setId(mcbUserServiceMapInfoPK);
			// Take system date as Updated date and Created date
			mcbUserServiceMapInfo.setCreatedDate(new java.sql.Date(new Date().getTime()));
			mcbUserServiceMapInfo.setUpdatedDate(new java.sql.Date(new Date().getTime()));
			
			
			
//			// Take system date as Updated date and Created date
//			if(service.getServiceId()==null) //If new user id is generated set created date
//			{
//				service.setCreatedDate(new java.sql.Date(new Date().getTime()));
//				System.out.println("NewUser");
//			}
//			else {
//				service.setCreatedDate( serviceService.findCreatedDate(service.getServiceId()));
//				System.out.println("ExistingUser");
//				}
//			service.setUpdatedDate(new java.sql.Date(new Date().getTime()));
			
			
			
			
			
			mcbUserServiceMapInfo.setHasAccess(mcbMap.getHasAccess());

			// save operation
			McbUserServiceMapInfoPK id = mappingService.saveUserService(mcbUserServiceMapInfo);
			// clean form
			model.addAttribute("mcbMap", new McbMap());
			// return message to UI
			model.addAttribute("message",
					"User " + id.getUserId() + "Has been given access to use " + id.getServiceId() + " service");
			List<McbServicesInfo> services = serviceService.getAllMCBServices();
			model.addAttribute("serviceList", services);

			List<McbUserInfo> users = userService.getAllUsers();
			model.addAttribute("userList", users);
			return "MappingRegister";
		} else {
			return "login";
		}
	}

	// 3. display all mapped values
	@RequestMapping("/all")
	public String findUsersServiceMap(@ModelAttribute McbMap mcbMap, Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {

			List<McbDto> mcbDtoList = mappingService.findUsersServiceMap("Y");
			model.addAttribute("mcbDtoList", mcbDtoList);

			return "MappingData";
		} else {
			return "login";
		}
	}

	// 4. display all Services by User ID
	@RequestMapping("/serviceByUserId")
	public String serviceByUserId(@ModelAttribute McbMap mcbMap, Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {
			List<McbUserInfo> users = userService.getAllUsers();
			model.addAttribute("userList", users);

			Integer uId = mcbMap.getUserId();
			if (uId != null) {

				List<McbDto> mcbDtoList = mappingService.findServicesByUserId(uId);
				model.addAttribute("mcbDtoList", mcbDtoList);

			}
			return "MappingServiceByUserIDData";
		} else {
			return "login";
		}
	}

	// 5. display all Users by Service ID
	@RequestMapping("/userByServiceId")
	public String userByServiceId(@ModelAttribute McbMap mcbMap, Model model, HttpSession session) {
		if (session.getAttribute("UserName") != null) {
			List<McbServicesInfo> services = serviceService.getAllMCBServices();
			model.addAttribute("serviceList", services);

			Integer sId = mcbMap.getUserId();
			if (sId != null) {

				List<McbDto> mcbDtoList = mappingService.findUsersByServiceId(sId);
				model.addAttribute("mcbDtoList", mcbDtoList);

			}
			return "MappingUserByServiceIDData";
		} else {
			return "login";
		}
	}

}