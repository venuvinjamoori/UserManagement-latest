package com.mcb.services;

import java.util.Date;
import java.util.List;

import com.mcb.model.McbUserInfo;

public interface MCBUserService {

	public Integer saveUser(McbUserInfo user);
	public void deleteUser(Integer userId);
	public McbUserInfo getuserById(Integer userId);
	public List<McbUserInfo> getAllUsers();
	public String findPassByUserName(String userName);
	public Date findCreatedDate(Integer userId);
}
