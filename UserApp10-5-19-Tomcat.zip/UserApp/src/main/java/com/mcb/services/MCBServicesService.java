package com.mcb.services;

import java.util.Date;
import java.util.List;

import com.mcb.model.McbServicesInfo;
/**
 * Service interface for service mapping to user.
 * 
 * @author Administrator
 *
 */

public interface MCBServicesService {

	//
	public Integer saveMCBService(McbServicesInfo service);
	public void deleteMCBService(Integer serviceId);
	public McbServicesInfo getserviceById(Integer serviceId);
	public List<McbServicesInfo> getAllMCBServices();
	public Date findCreatedDate(Integer serviceId);
	
}
