package com.mcb.services;

import java.util.Date;
import java.util.List;

import com.mcb.model.McbDto;
import com.mcb.model.McbUserServiceMapInfo;
import com.mcb.model.McbUserServiceMapInfoPK;

/**
 * Service interface for service mapping to user.
 * 
 * @author Administrator
 *
 */
public interface MCBMappingService {
	//Map user to service
	public McbUserServiceMapInfoPK saveUserService(McbUserServiceMapInfo mapping);
	//Get all services used by users
	public List<McbUserServiceMapInfo> getAllMapping();
	//Get services by particular user id
	public List<McbDto> findServicesByUserId(Integer user_id);
	//Get users by particular service id
	public List<McbDto> findUsersByServiceId(Integer user_id);
	//Get all services used by users in which has access is No
	public List<McbDto> findUsersServiceMap(String has_access);
	
	public Date findCreatedDate(Integer userId,Integer serviceId);


}